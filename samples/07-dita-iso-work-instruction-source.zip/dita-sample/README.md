# WI-QA-8.5-014 — AI-Assisted Drafting of ISO 9001 / AS9100 Work Instructions Using Microsoft Foundry

A hypothetical writing sample by Nathan Smith, prepared for a fictional company (TechCoaches
Information Systems Design) to demonstrate DITA-based authoring of a quality-system Work
Instruction covering an AI-assisted documentation pipeline.

## What's here

```
.
├── WI-QA-8.5-014.ditamap        ← the DITA map
├── topics/
│   ├── wi-8500-014-overview.dita             (concept)
│   ├── wi-8500-014-data-handling.dita        (concept)
│   ├── wi-8500-014-roles.dita                (reference)
│   ├── wi-8500-014-configure-project.dita    (task)
│   ├── wi-8500-014-draft-wi.dita             (task)
│   ├── wi-8500-014-records.dita              (reference)
│   └── wi-8500-014-glossary.dita             (glossgroup / glossentry)
├── preview.html                 ← source for the rendered PDF preview
├── WI-QA-8.5-014-preview.pdf    ← rendered preview, for readers without a DITA toolchain
└── README.md
```

## Why this structure

The topic set intentionally uses four different DITA topic types to show range:

- **concept** — background a reader needs before acting (the pipeline's purpose and quality-
  system basis; the data-handling boundaries for defense/aerospace source content)
- **task** — procedures a reader follows step by step (configuring the Foundry project;
  drafting and releasing a Work Instruction)
- **reference** — lookup information (roles and responsibilities; required records and
  retention)
- **glossgroup/glossentry** — controlled terminology, cross-referenced from the topics that use
  each term

The map organizes these with `topichead` groupings (Concepts, Reference, Tasks, Records,
Glossary) rather than a flat list, and topics cross-reference each other with `xref` — both
common patterns in real DITA implementations that a flat single-topic sample wouldn't
demonstrate.

## Validating or rendering it yourself

All seven topic files and the map are well-formed DITA 1.3 XML (checked with `xmllint`). To
render them with the OASIS DITA Open Toolkit:

```bash
dita -i WI-QA-8.5-014.ditamap -f pdf -o output/
```

`WI-QA-8.5-014-preview.pdf` is a hand-styled rendering of the same content for anyone reviewing
this sample without DITA-OT installed — the DITA source is the authoritative artifact.

## Disclaimer

TechCoaches Information Systems Design is a fictional company. This Work Instruction does not
describe a real deployed system, and it contains no classified, export-controlled, or
proprietary information. Clause citations to ISO 9001:2015 and AS9100D are accurate to those
published standards; their application here is illustrative.
